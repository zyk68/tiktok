
# Multi-Agent Business MVP

## Install
pip install -r requirements.txt

## Run
uvicorn main:app --reload

## Open
http://127.0.0.1:8000/docs

## APIs
- GET /
- POST /agent/product
- POST /agent/ads
- POST /agent/support
- GET /dashboard
