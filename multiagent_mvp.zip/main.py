
from fastapi import FastAPI
from pydantic import BaseModel
import random, uuid

app = FastAPI(title="Multi-Agent Business MVP")

class ProductIn(BaseModel):
    title:str
    price:float=9.9

class MsgIn(BaseModel):
    message:str

@app.get("/")
def root():
    return {"status":"ok","system":"multi-agent-mvp"}

@app.post("/agent/product")
def product(p:ProductIn):
    return {
        "optimized_title": f"{p.title} Premium Hot Sale",
        "suggested_price": round(p.price*1.2,2)
    }

@app.post("/agent/ads")
def ads(p:ProductIn):
    return {
        "hooks":[
            f"Why everyone loves {p.title}",
            f"Upgrade now with {p.title}",
            f"Limited deal on {p.title}"
        ]
    }

@app.post("/agent/support")
def support(m:MsgIn):
    txt=m.message.lower()
    if "refund" in txt:
        reply="Refund request received. We will respond within 24h."
    else:
        reply="Thanks for contacting support."
    return {"reply":reply}

@app.get("/dashboard")
def dashboard():
    return {
        "orders": random.randint(50,200),
        "gmv": random.randint(1000,10000),
        "conversion_rate": round(random.uniform(1.5,6.5),2)
    }
